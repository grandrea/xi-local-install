--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.6
-- Dumped by pg_dump version 9.6.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

--
-- Data for Name: crosslinker; Type: TABLE DATA; Schema: public; Owner: bio_user
--

COPY crosslinker (id, name, mass, is_decoy, description, is_default) FROM stdin;
1	BS2G	96.02112055	f	crosslinker:SymetricSingleAminoAcidRestrictedCrossLinker:Name:BS2G;MASS:96.02112055;LINKEDAMINOACIDS:K,S,T,Y,nterm	\N
9	BS2G (K only)	96.02112055	f	crosslinker:SymetricSingleAminoAcidRestrictedCrossLinker:Name:BS2G;MASS:96.02112055;LINKEDAMINOACIDS:K,nterm	\N
2	BS3	138.06807961	f	crosslinker:SymetricSingleAminoAcidRestrictedCrossLinker:Name:BS3;MASS:138.06807961;LINKEDAMINOACIDS:K(0),S(0.2),T(0.2),Y(0.2),nterm(0)	\N
15	BS3 (K only)	138.06807	f	crosslinker:SymetricSingleAminoAcidRestrictedCrossLinker:Name:BS3;MASS:138.06807961;LINKEDAMINOACIDS:K(0),nterm(0);	\N
14	BS3+NH+OH	138.06807	f	crosslinker:SymetricSingleAminoAcidRestrictedCrossLinker:Name:BS3;MASS:138.06807961;LINKEDAMINOACIDS:K(0),S(0.2),T(0.2),Y(0.2),nterm(0);MODIFICATIONS:NH2,17.026549105,OH,18.0105647	t
7	BS3+NH+OH+INTERNAL	138.06807	f	crosslinker:SymetricSingleAminoAcidRestrictedCrossLinker:Name:BS3;MASS:138.06807961;LINKEDAMINOACIDS:K(0),S(0.2),T(0.2),Y(0.2),nterm(0);MODIFICATIONS:NH2,17.026549105,OH,18.0105647,LOOP,0	\N
146	BS3+HEPES	377.1746325	f	crosslinker:SymetricSingleAminoAcidRestrictedCrossLinker:Name:BS3+HEPES;MASS:377.1746325;LINKEDAMINOACIDS:K(0),S(0.2),T(0.2),Y(0.2),nterm(0)	f
147	BS3+HEPES	375.1589824	f	crosslinker:SymetricSingleAminoAcidRestrictedCrossLinker:Name:BS3+HEPES;MASS:375.1589824;LINKEDAMINOACIDS:K(0),S(0.2),T(0.2),Y(0.2),nterm(0)	f
151	BS3 (K) +NH+OH+loop	138.06807	f	crosslinker:SymetricSingleAminoAcidRestrictedCrossLinker:Name:BS3;MASS:138.06807961;LINKEDAMINOACIDS:K(0),nterm(0);MODIFICATIONS:NH2,17.026549105,OH,18.0105647,loop,0	\N
23	BS3 (K) +NH+OH	138.06807	f	crosslinker:SymetricSingleAminoAcidRestrictedCrossLinker:Name:BS3;MASS:138.06807961;LINKEDAMINOACIDS:K(0),nterm(0);MODIFICATIONS:NH2,17.026549105,OH,18.0105647	\N
165	BS3(K-KSTY)	138.06807961	f	crosslinker:AsymetricSingleAminoAcidRestrictedCrossLinker:Name:BS3(K-KSTY);MASS:138.06807961;FIRSTLINKEDAMINOACIDS:K(0),S(0.2),T(0.2),Y(0.2),nterm(0);SECONDLINKEDAMINOACIDS:NTERM,K	f
10	BS3-d4	142.0931769836	f	crosslinker:SymetricSingleAminoAcidRestrictedCrossLinker:Name:BS3-d4;MASS:142.0931769836;LINKEDAMINOACIDS:K(0),S(0.2),T(0.2),Y(0.2),nterm(0)	\N
12	EDC (N,Q -17)	-17.0260005250906	f	crosslinker:AsymetricSingleAminoAcidRestrictedCrossLinker:Name:EDC;MASS:-17.0260005250906;FIRSTLINKEDAMINOACIDS:N,Q,cterm;SECONDLINKEDAMINOACIDS:K,S,Y,T,nterm	\N
6	BS(PEG)5	302.13655	f	crosslinker:SymetricSingleAminoAcidRestrictedCrossLinker:Name:BS(PEG)5;MASS:302.13655;LINKEDAMINOACIDS:K(0),S(0.2),T(0.2),Y(0.2),nterm(0)	\N
26	TargetModification	0	f	crosslinker:DummyCrosslinker:Name:TargetModification	\N
8	BS3+NH+OH	138.06807	f	crosslinker:SymetricSingleAminoAcidRestrictedCrossLinker:Name:BS3;MASS:138.06807961;LINKEDAMINOACIDS:K(0),S(0.2),T(0.2),Y(0.2),nterm(0);MODIFICATIONS:NH2,17.026549105,OH,18.0105647	\N
17	OpenModification	0	f	crosslinker:DummyCrosslinker:Name:OpenModification	\N
24	EGS (KSTY)+NH2+OH	226.047738	f	crosslinker:SymetricSingleAminoAcidRestrictedCrossLinker:Name:EGS;MASS:226.047738;LINKEDAMINOACIDS:K(0),S(0.2),T(0.2),Y(0.2),nterm(0);MODIFICATIONS:NH2,17.026549105,OH,18.0105647	\N
25	BS2G (KSTY) (NH2 OH)	96.02112055	f	crosslinker:SymetricSingleAminoAcidRestrictedCrossLinker:Name:BS2G;MASS:96.02112055;LINKEDAMINOACIDS:K(0),S(0.2),T(0.2),Y(0.2),nterm(0);MODIFICATIONS:NH2,17.026549105,OH,18.0105647	\N
28	-2H	-2.01565007	f	crosslinker:AsymetricSingleAminoAcidRestrictedCrossLinker:Name:Tyr-2H;MASS:-2.01565007;FIRSTLINKEDAMINOACIDS:R,H,K,D,E,S,T,N,Q,C,U,G,P,A,V,I,L,M,F,Y,W;SECONDLINKEDAMINOACIDS:R,H,K,D,E,S,T,N,Q,C,U,G,P,A,V,I,L,M,F,Y,W	\N
30	-1H	-1.007825	f	crosslinker:AsymetricSingleAminoAcidRestrictedCrossLinker:Name:Tyr-1H;MASS:-1.007825;FIRSTLINKEDAMINOACIDS:R,H,K,D,E,S,T,N,Q,C,U,G,P,A,V,I,L,M,F,Y,W;SECONDLINKEDAMINOACIDS:R,H,K,D,E,S,T,N,Q,C,U,G,P,A,V,I,L,M,F,Y,W	\N
31	-3H	-3.023475	f	crosslinker:AsymetricSingleAminoAcidRestrictedCrossLinker:Name:Tyr-3H;MASS:-3.023475;FIRSTLINKEDAMINOACIDS:R,H,K,D,E,S,T,N,Q,C,U,G,P,A,V,I,L,M,F,Y,W;SECONDLINKEDAMINOACIDS:R,H,K,D,E,S,T,N,Q,C,U,G,P,A,V,I,L,M,F,Y,W	\N
32	-OH	-17.002740	f	crosslinker:AsymetricSingleAminoAcidRestrictedCrossLinker:Name:Tyr-OH;MASS:-17.002740;FIRSTLINKEDAMINOACIDS:R,H,K,D,E,S,T,N,Q,C,U,G,P,A,V,I,L,M,F,Y,W;SECONDLINKEDAMINOACIDS:R,H,K,D,E,S,T,N,Q,C,U,G,P,A,V,I,L,M,F,Y,W	\N
38	BENZO (C14H8O2)	208.052430	f	crosslinker:AsymetricSingleAminoAcidRestrictedCrossLinker:Name:BENZO;MASS:208.052430;FIRSTLINKEDAMINOACIDS:R,H,K,D,E,S,T,N,Q,C,U,G,P,A,V,I,L,M,F,Y,W,K8,Ccm,Mox;SECONDLINKEDAMINOACIDS:K,S,Y,T,K8,nterm	\N
46	BPM	277.073894	f	crosslinker:AsymetricSingleAminoAcidRestrictedCrossLinker:Name:BPM;MASS:277.073894;FIRSTLINKEDAMINOACIDS:R,H,K,D,E,S,T,N,Q,C,U,G,P,A,V,I,L,M,F,Y,W,Mox,Ccm;SECONDLINKEDAMINOACIDS:C	\N
48	DSSO+NH+OH	158.0037648	f	crosslinker:SymetricSingleAminoAcidRestrictedCrossLinker:Name:DSSO;MASS:158.0037648;LINKEDAMINOACIDS:K(0),S(0.2),T(0.2),Y(0.2),nterm(0);MODIFICATIONS:NH2,17.026549105,OH,18.0105647	\N
51	DSP (loop,amidated,hydrolized)	173.98092087	f	crosslinker:SymetricSingleAminoAcidRestrictedCrossLinker:Name:DSP;MASS:173.98092087;LINKEDAMINOACIDS:K(0),S(0.2),T(0.2),Y(0.2),nterm(0);MODIFICATIONS:NH2,17.026549105,OH,18.0105647,LOOP,0	\N
52	DSP (amidated,hydrolized)	173.98092087	f	crosslinker:SymetricSingleAminoAcidRestrictedCrossLinker:Name:DSP;MASS:173.98092087;LINKEDAMINOACIDS:K(0),S(0.2),T(0.2),Y(0.2),nterm(0);MODIFICATIONS:NH2,17.026549105,OH,18.0105647	\N
33	Linear Search	0	f	crosslinker:LinearCrosslinker:NAME:linear	\N
115	DTSSP	173.98092087	f	crosslinker:SymetricSingleAminoAcidRestrictedCrossLinker:Name:DTSSP;MASS:173.98092087;LINKEDAMINOACIDS:K(0),S(0.2),T(0.2),Y(0.2),nterm(0)	\N
117	NonCovalent	0	f	crosslinker:NonCovalentBound:Name:NonCovalent	\N
116	DTSSP+TRIS+OH	173.98092087	f	crosslinker:SymetricSingleAminoAcidRestrictedCrossLinker:Name:DTSSP;MASS:173.98092087;LINKEDAMINOACIDS:K(0),S(0.2),T(0.2),Y(0.2),nterm(0);MODIFICATIONS:TRIS,121.073893275,OH,18.0105647	\N
119	DTSSP+Disulphide	171.9652708	f	crosslinker:SymetricSingleAminoAcidRestrictedCrossLinker:Name:disulph+dtssp;MASS:171.9652708;LINKEDAMINOACIDS:C,K,S,T,Y	\N
118	Disulphide	-2.01565007	f	crosslinker:SymetricSingleAminoAcidRestrictedCrossLinker:Name:Disulphide;MASS:-2.01565007;LINKEDAMINOACIDS:C	\N
120	Shuffled DTSSP (KSTY to C)	85.9826354	f	crosslinker:AsymetricSingleAminoAcidRestrictedCrossLinker:Name:SDTSSP;MASS:85.9826354;FIRSTLINKEDAMINOACIDS:K,S,T,Y;SECONDLINKEDAMINOACIDS:C	\N
121	SDA	82.04186484	f	crosslinker:AsymetricSingleAminoAcidRestrictedCrossLinker:Name:SDA;MASS:82.04186484;FIRSTLINKEDAMINOACIDS:R,H,K,D,E,S,T,N,Q,C,U,G,P,A,V,I,L,M,F,Y,W;SECONDLINKEDAMINOACIDS:K,S,Y,T,K8,nterm	\N
29	LC-SDA	195.125928855	f	crosslinker:AsymetricSingleAminoAcidRestrictedCrossLinker:Name:LC-SDA;MASS:195.125928855;FIRSTLINKEDAMINOACIDS:R,H,K,D,E,S,T,N,Q,C,U,G,P,A,V,I,L,M,F,Y,W;SECONDLINKEDAMINOACIDS:K,S,Y,T,nterm	\N
131	BMPS	151.026943065	f	crosslinker:AsymetricSingleAminoAcidRestrictedCrossLinker:Name:BMPS;MASS:151.026943065;FIRSTLINKEDAMINOACIDS:K,S,T,Y,nterm;SECONDLINKEDAMINOACIDS:C	\N
139	DSSO	158.0037648	f	crosslinker:SymetricSingleAminoAcidRestrictedCrossLinker:Name:DSSO;MASS:158.0037648;LINKEDAMINOACIDS:K(0),S(0.2),T(0.2),Y(0.2),nterm(0)	f
5	EDC	-18.01056027	f	crosslinker:AsymetricSingleAminoAcidRestrictedCrossLinker:Name:EDC;MASS:-18.01056027;FIRSTLINKEDAMINOACIDS:E,D,cterm;SECONDLINKEDAMINOACIDS:K,S,Y,T,nterm	\N
166	Ubiquitinlike	-18.0105647	f	crosslinker:AsymetricSingleAminoAcidRestrictedCrossLinker:Name:Ubiquitinlike;MASS:-18.0105647;FIRSTLINKEDAMINOACIDS:CTERM;SECONDLINKEDAMINOACIDS:X	f
162	EDC (no STY)	-18.01056027	f	crosslinker:AsymetricSingleAminoAcidRestrictedCrossLinker:Name:EDC (no STY);MASS:-18.01056027;FIRSTLINKEDAMINOACIDS:E,D,cterm;SECONDLINKEDAMINOACIDS:K,nterm	f
177	DSSO (K only)	158.0037648	f	crosslinker:SymetricSingleAminoAcidRestrictedCrossLinker:Name:DSSO (K only);MASS:158.0037648;LINKEDAMINOACIDS:K(0),nterm(0)	f
178	Dummy	0	f	crosslinker:SymetricSingleAminoAcidRestrictedCrossLinker:Name:Dummy;MASS:0;LINKEDAMINOACIDS:X	f
181	SDA_Knterm	82.04186484	f	crosslinker:AsymetricSingleAminoAcidRestrictedCrossLinker:Name:SDA_Knterm;MASS:82.04186484;FIRSTLINKEDAMINOACIDS:R,H,K,D,E,S,T,N,Q,C,U,G,P,A,V,I,L,M,F,Y,W;SECONDLINKEDAMINOACIDS:K,nterm	f
182	BS3_loss56+NH2+OH	82.0081	f	crosslinker:SymetricSingleAminoAcidRestrictedCrossLinker:Name:BS3_loss56;MASS:82.0081;LINKEDAMINOACIDS:K(0),S(0.2),T(0.2),Y(0.2),nterm(0);MODIFICATIONS:NH2,17.026549105,OH,18.0105647	f
183	DSBU	196.08479231	f	crosslinker:SymetricSingleAminoAcidRestrictedCrossLinker:Name:DSBU;MASS:196.08479231;LINKEDAMINOACIDS:K(0),S(0.2),T(0.2),Y(0.2),nterm(0)	f
\.


--
-- Name: crosslinker_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bio_user
--

SELECT pg_catalog.setval('crosslinker_id_seq', 200, true);


--
-- Data for Name: modification; Type: TABLE DATA; Schema: public; Owner: bio_user
--

COPY modification (id, name, description, formula, symbol, is_default_fixed, is_default_var) FROM stdin;
13	K120	:SYMBOL:K120;MODIFIED:K;MASS:248.11737	\N	\N	\N	\N
63	SDA-oxid	:SYMBOLEXT:sda-oxid;MODIFIED:K,S,T,Y;DELTAMASS:98.036780	\N	sda-alk	\N	\N
3	PhosphoSerine	:SYMBOL:Sp;MODIFIED:S;MASS:166.9984	PO3H	p	\N	\N
4	PhosphoThreonine	:SYMBOL:Tp;MODIFIED:T;MASS:181.0140	PO3H	p	\N	\N
5	PhosphoTyrosine	:SYMBOL:Yp;MODIFIED:Y;MASS:243.0296	PO3H	p	\N	\N
6	Deamidation (N)	:SYMBOL:Nda;MODIFIED:N;MASS:115.026397	O -H -N	da	\N	\N
7	Deamidation (Q)	:SYMBOL:Qda;MODIFIED:Q;MASS:129.042047	O -H -N	da	\N	\N
8	Arg6	:SYMBOL:R6;MODIFIED:R;MASS:162.121239	13C6 -C6	6	\N	\N
9	Arg10	:SYMBOL:R10;MODIFIED:R;MASS:166.1093789	13C10 -C10	10	\N	\N
10	Lys4	:SYMBOL:K4;MODIFIED:K;MASS:132.120067	2H4 -4H	4	\N	\N
11	Lys6	:SYMBOL:K6;MODIFIED:K;MASS:134.115089	13C6 -C6	6	\N	\N
12	Lys8	:SYMBOL:K8;MODIFIED:K;MASS:136.1091589	13C8 -C8	8	\N	\N
14	Oxidised Carbamidomethylation	:SYMBOL:Ccmo;MODIFIED:C;MASS:176.025569	C2H3NO2	cmo	\N	\N
15	Oxidation (Q)	:SYMBOL:Qox;MODIFIED:Q;MASS:144.053499	O	ox	\N	\N
16	Oxidation (N)	:SYMBOL:Nox;MODIFIED:N;MASS:130.037849	O	ox	\N	\N
17	Methylation (R)	:SYMBOLEXT:me;MODIFIED:R;DELTAMASS:14.015650	H2 C	me	\N	\N
18	Methylation (K)	:SYMBOLEXT:me;MODIFIED:K;DELTAMASS:14.015650	H2 C	me	\N	\N
19	Dimethylation (R)	:SYMBOLEXT:dme;MODIFIED:R;DELTAMASS:28.031300	H4 C2	dme	\N	\N
20	Dimethylation (K)	:SYMBOLEXT:dme;MODIFIED:K;DELTAMASS:28.031300	H4 C2	dme	\N	\N
21	Trimethylation (R)	:SYMBOLEXT:tme;MODIFIED:R;DELTAMASS:42.046950	H6 C3	tme	\N	\N
22	Trimethylation (K)	:SYMBOLEXT:tme;MODIFIED:K;DELTAMASS:42.046950	H6 C3	tme	\N	\N
23	Acetylation (K)	:SYMBOLEXT:ac;MODIFIED:K;DELTAMASS:42.010565	C2 H2 O	ac	\N	\N
24	Ubiquitinylation residue/GlyGly	:SYMBOLEXT:ub;MODIFIED:K;DELTAMASS:114.042927	H6 C4 N2 O2	ub	\N	\N
25	Methylation (E)	:SYMBOLEXT:me;MODIFIED:E;DELTAMASS:14.015650	H2 C	me	\N	\N
26	Glutamylation (E)	:SYMBOLEXT:glu;MODIFIED:E;DELTAMASS:129.0426	H7 C5 N O3	glu	\N	\N
27	WaterLoss (E)	:SYMBOLEXT:h2o;MODIFIED:E;DELTAMASS:-18.0105647	-H2 -O	h20	\N	\N
66	azidophenylalanine (F)	:SYMBOLEXT:az;MODIFIED:F;DELTAMASS:41.001396965	az	N3 -H1	\N	\N
31	BENZO_HYD	:SYMBOLEXT:benzo_hyd;MODIFIED:K,S,T,Y;DELTAMASS:226.062995	C14 H10 O3	benzo_hyd	\N	\N
32	BENZO	:SYMBOLEXT:benzo_hyd;MODIFIED:R,H,K,D,E,S,T,N,Q,C,U,G,P,A,V,I,L,M,F,Y,W;DELTAMASS:208.052430	C14 H8 O2	benzo_hyd	\N	\N
44	2OH Formyl Kynorenine	:SYMBOLEXT:2ohfk;MODIFIED:W;DELTAMASS:63.97965852	\N	2ohfk	\N	\N
43	Kynurenine	:SYMBOLEXT:kynur;MODIFIED:W;DELTAMASS:3.99491463	\N	kynur	\N	\N
40	Oxidation(CWFYHP)	:SYMBOLEXT:ox;MODIFIED:C,W,F,Y,H,P;DELTAMASS:15.99491463	O	ox	\N	\N
41	Dioxidation(CWF)	:SYMBOLEXT:dox;MODIFIED:C,W,F;DELTAMASS:31.98982926	2O	dox	\N	\N
37	-1H	:SYMBOLEXT:h;MODIFIED:R,H,K,D,E,S,T,N,Q,C,U,G,P,A,V,I,L,M,F,Y,W;DELTAMASS:-1.00782504	-1	h	\N	\N
42	Trioxidation(C)	:SYMBOLEXT:tox;MODIFIED:C;DELTAMASS:47.98474389	3O	tox	\N	\N
45	OH Kynorenine	:SYMBOLEXT:ohk;MODIFIED:W;DELTAMASS:19.98982963	\N	ohk	\N	\N
46	His-Asp-conversion	:SYMBOLEXT:hdc;MODIFIED:H;DELTAMASS:-23.015984	\N	hdc	\N	\N
47	His-Asn-conversion	:SYMBOLEXT:hnc;MODIFIED:H;DELTAMASS:-22.031969	\N	hnc	\N	\N
48	Glutamic semialdehyole	:SYMBOLEXT:gsa;MODIFIED:R;DELTAMASS:-43.053433	\N	gsa	\N	\N
49	Aminoadipic semialdehyole	:SYMBOLEXT:asa;MODIFIED:K;DELTAMASS:-1.031634	\N	asa	\N	\N
50	Pyrrolidone	:SYMBOLEXT:pyrr;MODIFIED:P;DELTAMASS:-27.994915	\N	pyrr	\N	\N
51	Pyroglutmic acid	:SYMBOLEXT:pyrglu;MODIFIED:P;DELTAMASS:13.97926456	\N	pyrglu	\N	\N
52	-2H(T)	:SYMBOLEXT:-2h;MODIFIED:T;DELTAMASS:-2.01565007	\N	-2h	\N	\N
56	Selenium replace Sulfur 	:SYMBOLEXT:sse;MODIFIED:M;DELTAMASS:46.895	Se -S	sse	\N	\N
58	Carbamidomethyl(K)	:SYMBOLEXT:cm;MODIFIED:K;DELTAMASS:57.021464	\N	cm	\N	\N
59	Carbamidomethyl(H)	:SYMBOLEXT:cm;MODIFIED:H;DELTAMASS:57.021464	\N	cm	\N	\N
2	Oxidation (M)	:SYMBOL:Mox;MODIFIED:M;MASS:147.035395	O	ox	\N	t
1	Carbamidomethylation	:SYMBOL:Ccm;MODIFIED:C;MASS:160.03065	H3C2NO	cm	t	\N
60	NTerm-26	:SYMBOLEXT:26;MODIFIED:R,H,K,D,E,S,T,N,Q,C,U,G,P,A,V,I,L,M,F,Y,W;DELTAMASS:26.061528	\N	\N	\N	\N
62	SDA-alkene	:SYMBOLEXT:sda-alk;MODIFIED:K,S,T,Y;DELTAMASS:68.026215	\N	sda-alk	\N	\N
64	SDA-Hydro	:SYMBOLEXT:sda-hyd;MODIFIED:K,S,T,Y;DELTAMASS:100.05243	C5 H8 O2	sda-hyd	\N	\N
29	SDA	:SYMBOLEXT:sda;MODIFIED:K,S,T,Y;DELTAMASS:110.04801284	C5 H6 N2 O	sda	\N	\N
30	SDA-loop	:SYMBOLEXT:sda-loop;MODIFIED:K,S,T,Y;DELTAMASS:82.04186484	C5 H6 O	sda-loop	\N	\N
133	Part DTSSP+H (KSTY)	:SYMBOLEXT:sdtssp;MODIFIED:K,S,T,Y;DELTAMASS:87.99828547	C3 H4 O1 S1	sdtssp	f	f
134	Uridine-H3PO4(AILKFWY)	:SYMBOLEXT:uh3po4;MODIFIED:A,I,L,K,F,W,Y,V;DELTAMASS:226.058972	C9 H10 N2 O5	uh3po4	\N	\N
139	Acetylation (K)	:SYMBOLEXT:ac;MODIFIED:K;DELTAMASS:42.010565	C2 H2 O	ac	\N	\N
135	Methylation (D)	:SYMBOLEXT:me;MODIFIED:D;DELTAMASS:14.015650	H2 C	me	\N	\N
136	BS3Loop Anywhere	:SYMBOLEXT:bs3loop;MODIFIED:*;DELTAMASS:138.06807	\N	bs3loop	\N	\N
137	BS3Amidated Anywhere	:SYMBOLEXT:bs3nh;MODIFIED:*;DELTAMASS:155.094619105	\N	bs3nh	\N	\N
138	BS3ydrolized Anywhere	:SYMBOLEXT:bs3oh;MODIFIED:*;DELTAMASS:156.0786347	\N	bs3oh	\N	\N
140	Acetylation(Prot.N-Term)	:SYMBOLEXT:ac;MODIFIED:*;DELTAMASS:42.010565;PROTEINPOSITION:nterm	C2 H2 O	ac	\N	\N
141	Hydroxyaspartic acid (D)	:SYMBOL:Doh;MODIFIED:D;MASS:131.021858	C4 H5 N O4	oh	\N	\N
142	Carboxyglutamic acid (E)	:SYMBOL:Ecooh;MODIFIED:E;MASS:173.032422	C6 H7 N O5	cooh	\N	\N
55	BS3Loop	:SYMBOLEXT:bs3loop;MODIFIED:K,S,T,Y;DELTAMASS:138.06807	\N	bs3loop	\N	\N
145	BMPS(KSTY)	:SYMBOLEXT:bmps;MODIFIED:K,S,T,Y;DELTAMASS:151.026943065	C11 O6 N2 H14	\N	\N	\N
146	BMPS-DTT(KSTY)	:SYMBOLEXT:bmps-dtt;MODIFIED:K,S,T,Y;DELTAMASS:305.039164075	C11 O5 N1 S2 H15	\N	\N	\N
147	BMPS-DTT-IAA(KSTY)	:SYMBOLEXT:bmps-dttiaa;MODIFIED:K,S,T,Y;DELTAMASS:348.04497774000004	C12 O6 N2 S2 H16	\N	\N	\N
143	BMPS-Tris(C)	:SYMBOLEXT:bmps-tris;MODIFIED:C;DELTAMASS:272.10083634	C11 O6 N2 H14	bmps-tris	\N	\N
148	BMPS-OH(C)	:SYMBOLEXT:bmps-oh;MODIFIED:C;DELTAMASS:169.037507765	C7 O4 N1 H7	bmps-oh	\N	\N
39	CarbAM (CKHDEST)	:SYMBOLEXT:cm;MODIFIED:C,K,H,D,E,S,T,Y;DELTAMASS:57.021463735	H3C2NO	cm	\N	\N
151	BS3-TRIS(KSTY)	:SYMBOLEXT:bs3tris;MODIFIED:K,S,T,Y;DELTAMASS:259.141972885	C12 H21 N1 O5	bs3tris	\N	\N
54	BS3Hydrolized	:SYMBOLEXT:bs3oh;MODIFIED:K,S,T,Y;DELTAMASS:156.0786347	\N	bs3oh	\N	\N
53	BS3Amidated	:SYMBOLEXT:bs3nh;MODIFIED:K,S,T,Y;DELTAMASS:155.094619105	\N	bs3nh	\N	\N
152	BS3Amidated(K)	:SYMBOLEXT:bs3nh;MODIFIED:K;DELTAMASS:155.094628715	\N	bs3nh	\N	\N
153	BS3Hydrolized(K)	:SYMBOLEXT:bs3oh;MODIFIED:K;DELTAMASS:156.07864431	\N	bs3oh	\N	\N
154	BS3Loop(K)	:SYMBOLEXT:bs3loop;MODIFIED:K;DELTAMASS:138.06807961	\N	bs3loop	\N	\N
155	BS3Amidated(S)	:SYMBOLEXT:bs3nh;MODIFIED:S;DELTAMASS:155.094628715	\N	bs3nh	\N	\N
156	BS3Hydrolized(S)	:SYMBOLEXT:bs3oh;MODIFIED:S;DELTAMASS:156.07864431	\N	bs3oh	\N	\N
157	BS3Loop(S)	:SYMBOLEXT:bs3loop;MODIFIED:S;DELTAMASS:138.06807961	\N	bs3loop	\N	\N
158	BS3Amidated(T)	:SYMBOLEXT:bs3nh;MODIFIED:T;DELTAMASS:155.094628715	\N	bs3nh	\N	\N
159	BS3Hydrolized(T)	:SYMBOLEXT:bs3oh;MODIFIED:T;DELTAMASS:156.07864431	\N	bs3oh	\N	\N
160	BS3Loop(T)	:SYMBOLEXT:bs3loop;MODIFIED:T;DELTAMASS:138.06807961	\N	bs3loop	\N	\N
161	BS3Amidated(Y)	:SYMBOLEXT:bs3nh;MODIFIED:Y;DELTAMASS:155.094628715	\N	bs3nh	\N	\N
162	BS3Hydrolized(Y)	:SYMBOLEXT:bs3oh;MODIFIED:Y;DELTAMASS:156.07864431	\N	bs3oh	\N	\N
163	BS3Loop(Y)	:SYMBOLEXT:bs3loop;MODIFIED:Y;DELTAMASS:138.06807961	\N	bs3loop	\N	\N
167	Propionamide(nterm)	:SYMBOLEXT:ce;MODIFIED:*;DELTAMASS:71.037113805;PROTEINPOSITION:nterm	\N	ce	\N	\N
166	Propionamide(K)	:SYMBOLEXT:ce;MODIFIED:K;DELTAMASS:71.037113805	\N	ce	\N	\N
164	Propionamide(C)	:SYMBOLEXT:ce;MODIFIED:C;DELTAMASS:71.037113805	\N	ce	\N	\N
170	Ubiquitinylation residue/CysGly	:SYMBOLEXT:ub;MODIFIED:C;DELTAMASS:231.043953	C8 H11 N2 O4 S	ub	\N	\N
169	Zero	:SYMBOLEXT:0;MODIFIED:*;DELTAMASS:0.0001	\N	\N	\N	\N
172	Carbamidomethyl(PepNTerm)	:SYMBOLEXT:cm;MODIFIED:X;DELTAMASS:57.021464;PEPTIDEPOSITION:nterm	H3C2NO	\N	\N	\N
\.


--
-- Name: modification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bio_user
--

SELECT pg_catalog.setval('modification_id_seq', 172, true);


--
-- PostgreSQL database dump complete
--

